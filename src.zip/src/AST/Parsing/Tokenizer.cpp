#include "Tokenizer.hpp"

namespace AST
{
void Tokenizer::skipWhitespace()
{
    while (pos < src.length() && (src[pos] == ' ' || src[pos] == '\t' || src[pos] == '\n' || src[pos] == '\r'))
    {
        pos++;
    }
}
Token Tokenizer::extractLiteral()
{
    std::string token = "";
    while (pos < src.length() && ((src[pos] >= '0' && src[pos] <= '9') || src[pos] == '.'))
    {
        token += src[pos];
        pos++;
    }
    return Token(TokenType::NUMBER, token);
}

Token Tokenizer::extractIdentifier()
{
    std::string token = "";
    while (pos < src.length() && ((src[pos] >= 'a' && src[pos] <= 'z') ||
        (src[pos] >= 'A' && src[pos] <= 'Z') ||
        src[pos] == '_'))
    {

        token += src[pos];
        pos++;
        auto format = OpRegistry::getOperationFormat(token);
        if(format != OpDefinition::Format::NONE)
            return Token(TokenType::OPERATION, token, format);

    }
    return Token(TokenType::VARIABLE, token);
}
Token Tokenizer::extractUnknown()
{
// unknowns (operators/symbols),scan contiguous nonalphanumeric characters
    std::string token = "";
    while (pos < src.length())
    {
        char current = src[pos];

        // Stop scanning operator cluster if we hit whitespace, brackets, digits, or letters
        if (current == ' ' || current == '\t' || current == '\n' || current == '\r' ||
            current == '(' || current == ')' ||
            (current >= '0' && current <= '9') ||
            (current >= 'a' && current <= 'z') || (current >= 'A' && current <= 'Z') || current == '_')
        {
            break;
        }

        token += current;
        pos++;
        if(current == ',')
            break;

        auto format = OpRegistry::getOperationFormat(token);
        if(format != OpDefinition::Format::NONE)
            return Token(TokenType::OPERATION, token, format);
    }
    return Token(TokenType::UNKNOWN, token);
}
Token Tokenizer::next()
{
    skipWhitespace();

    // the last token was just whitespace, just send an empty token for the parser to deal with
    if (pos >= src.length())
        return Token(TokenType::UNKNOWN, "");

    char ch = src[pos];

    // delimiters, always single characters
    if (ch == '(')
    {
        pos++;
        return Token(TokenType::L_BRACKET, "(");
    }
    if (ch == ')')
    {
        pos++;
        return Token(TokenType::R_BRACKET, ")");
    }
    if(ch == ',')
    {
        pos++;
        return Token(TokenType::COMMA,",");
    }

    // multicharacter literals
    if ((ch >= '0' && ch <= '9') || ch == '.')
    {
        return extractLiteral();
    }

    // multicharacter identifiers
    if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || ch == '_')
    {
        return extractIdentifier();
    }

    return extractUnknown();
}

std::vector<Token> Tokenizer::tokenize()
{
    pos = 0;
    std::vector<Token> res;
    while (pos < src.length())
    {
        Token nxt = next();
        res.push_back(nxt);
    }

    if(Config::DEBUG_MODE)
    {
        std::cout << "PRE NORMALIZATION: ";
        for(auto arg:res)
        {
            std::cout<<arg<<", ";
        }
        std::cout<<std::endl;
    }
    // normalize tokens for parser

    for(size_t i=0;i<res.size();i++)
    {
        auto& token = res[i];
        
        if(token.type == TokenType::NUMBER || token.type == TokenType::VARIABLE || token.type == TokenType::R_BRACKET)
        {
            // check if the next token is an identifier/bracket, if it is, implicit multiplication
            if(i+1 < res.size() && (res[i+1].type == TokenType::VARIABLE || res[i+1].type == TokenType::NUMBER || res[i+1].type == TokenType::L_BRACKET || (res[i+1].type == TokenType::OPERATION && res[i+1].format != OpDefinition::Format::INFIX)))
            {
                // insert a multiplication operator between the two tokens
                res.insert(res.begin() + i + 1, Token(TokenType::OPERATION, "[implicit*]", OpDefinition::Format::INFIX));
                i++; // skip the next token since we just inserted a new one
            }
        }
        else if(token.value == "-")
        {
            // check if the next token is some kind of identifier, another prefix or another subtraction/negation
            if(i+1 < res.size() && 
            (res[i+1].type == TokenType::NUMBER ||
                res[i+1].type == TokenType::VARIABLE ||
                res[i+1].type == TokenType::L_BRACKET||
                (res[i+1].type == TokenType::OPERATION && res[i+1].format == OpDefinition::Format::PREFIX) ||
                res[i+1].value == "-")) // ensure chains of - are caught, as ordinary subtraction doesn't count as a prefix
            {
                // if the previous token is a literal or identifier, keep it binary subtraction
                if(i > 0 && (res[i-1].type == TokenType::NUMBER || res[i-1].type == TokenType::VARIABLE || res[i-1].type == TokenType::R_BRACKET))
                {
                    continue;
                }
                res[i] = Token(TokenType::OPERATION, "unary-", OpDefinition::Format::PREFIX); // change the token to a unary minus operator                
            }
            
        }
    }
    if(Config::DEBUG_MODE)
    {
        std::cout << "POST NORMALIZATION: ";
        for(auto arg:res)
        {
            std::cout<<arg<<", ";
        }
        std::cout<<std::endl;
    }
    return res;
}

};