#include "Tokenizer.hpp"

namespace AST
{
void Tokenizer::skipWhitespace()
{
    while (pos < src.length() && (src[pos] == ' ' || src[pos] == '\t' || src[pos] == '\n' || src[pos] == '\r'))
    {
        pos++;
    }
}
Token Tokenizer::extractLiteral()
{
    std::string token = "";
    while (pos < src.length() && ((src[pos] >= '0' && src[pos] <= '9') || src[pos] == '.'))
    {
        token += src[pos];
        pos++;
    }
    return Token(TokenType::NUMBER, token);
}

Token Tokenizer::extractIdentifier()
{
    std::string token = "";
    while (pos < src.length() && ((src[pos] >= 'a' && src[pos] <= 'z') ||
        (src[pos] >= 'A' && src[pos] <= 'Z') ||
        (src[pos] >= '0' && src[pos] <= '9') ||
        src[pos] == '_'))
    {

        token += src[pos];
        pos++;
        auto format = registry.getOperationFormat(token);
        if(format != OpDefiniton::Format::NONE)
            return Token(TokenType::OPERATION, token, format);
        else if(Environment::isCommonIdentifier(token))
            return Token(TokenType::VARIABLE,token);
    }
    return Token(TokenType::VARIABLE, token);
}
Token Tokenizer::extractUnknown()
{
// unknowns (operators/symbols),scan contiguous nonalphanumeric characters
    std::string token = "";
    while (pos < src.length())
    {
        char current = src[pos];

        // Stop scanning operator cluster if we hit whitespace, brackets, digits, or letters
        if (current == ' ' || current == '\t' || current == '\n' || current == '\r' ||
            current == '(' || current == ')' ||
            (current >= '0' && current <= '9') ||
            (current >= 'a' && current <= 'z') || (current >= 'A' && current <= 'Z') || current == '_')
        {
            break;
        }

        token += current;
        pos++;
        if(current == ',')
            break;

        auto format = registry.getOperationFormat(token);
        if(format != OpDefiniton::Format::NONE)
            return Token(TokenType::OPERATION, token, format);
    }
    return Token(TokenType::UNKNOWN, token);
}
Token Tokenizer::next()
{
    skipWhitespace();

    // the last token was just whitespace, just send an empty token for the parser to deal with
    if (pos >= src.length())
        return Token(TokenType::UNKNOWN, "");

    char ch = src[pos];

    // delimiters, always single characters
    if (ch == '(')
    {
        pos++;
        return Token(TokenType::L_BRACKET, "(");
    }
    if (ch == ')')
    {
        pos++;
        return Token(TokenType::R_BRACKET, ")");
    }

    // multicharacter literals
    if ((ch >= '0' && ch <= '9') || ch == '.')
    {
        return extractLiteral();
    }

    // multicharacter identifiers
    if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || ch == '_')
    {
        return extractIdentifier();
    }

    return extractUnknown();
}

std::vector<Token> Tokenizer::tokenize()
{
    pos = 0;
    std::vector<Token> res;
    while (pos < src.length())
    {
        Token nxt = next();
        res.push_back(nxt);
    }

    // normalize

    for(size_t i=0;i<res.size();i++)
    {
        auto& token = res[i];
        
        if(token.type == TokenType::NUMBER || token.type == TokenType::VARIABLE || token.type == TokenType::R_BRACKET)
        {
            // check if the next token is an identifier/bracket, if it is, implicit multiplication
            if(i+1 < res.size() && (res[i+1].type == TokenType::VARIABLE || res[i+1].type == TokenType::NUMBER || res[i+1].type == TokenType::L_BRACKET || res[i+1].type == TokenType::OPERATION && res[i+1].format == OpDefiniton::Format::PREFIX))
            {
                // insert a multiplication operator between the two tokens
                res.insert(res.begin() + i + 1, Token(TokenType::OPERATION, "[implicit*]"));
                i++; // skip the next token since we just inserted a new one
            }
        }
        else if(token.value == "-")
        {
            // check if the next token is a literal or identifier, if it is, change the token to a unary minus operator
            if(i+1 < res.size() && (res[i+1].type == TokenType::NUMBER || res[i+1].type == TokenType::VARIABLE || res[i+1].type == TokenType::L_BRACKET|| res[i+1].type == TokenType::OPERATION && res[i+1].format == OpDefiniton::Format::PREFIX))
            {
                // if the previous token is a literal or identifier, keep it binary subtraction
                if(i > 0 && (res[i-1].type == TokenType::NUMBER || res[i-1].type == TokenType::VARIABLE || res[i-1].type == TokenType::R_BRACKET))
                {
                    continue;
                }
                res[i] = Token(TokenType::NUMBER, "-1"); // change the token to a unary minus operator
                // change the token to a unary minus operator
                
                i++;
                res.insert(res.begin() + i, Token(TokenType::OPERATION, "[implicit*]"));
            }
        }
    }
    for(auto arg:res)
    {
        std::cout<<arg<<", ";
    }
    std::cout<<std::endl;
    return res;
}

};